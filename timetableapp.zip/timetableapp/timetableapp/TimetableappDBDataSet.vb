﻿Partial Class TimetableappDBDataSet
End Class

Namespace TimetableappDBDataSetTableAdapters
    Partial Public Class LecturerAccountTableAdapter
    End Class
End Namespace

Namespace timetableapp.TimetableappDBDataSetTableAdapters

    Partial Public Class StudentTimetableTableAdapter
    End Class
End Namespace
