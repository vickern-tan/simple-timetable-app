﻿Public Class StudentProfile
    Private Sub StudentProfile_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class